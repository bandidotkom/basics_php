<?php
 $cn = new mysqli("usersql.zedat.fu-berlin.de","gundel-sql",
	   "123", "gundel-db1");
?>